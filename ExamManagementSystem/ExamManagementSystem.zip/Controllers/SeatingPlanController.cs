﻿// SeatingPlanController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SelectPdf;
using ExamManagementSystem.Data;
using ExamManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExamManagementSystem.Controllers
{
    public class SeatingPlanController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SeatingPlanController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Generate()
        {
            ViewBag.Batches = new SelectList(_context.Batches, "Id", "Name");
            ViewBag.Sections = new SelectList(_context.Sections, "Id", "Name");
            ViewBag.Courses = new SelectList(_context.Courses, "Id", "Name");
            ViewBag.Rooms = new SelectList(_context.Rooms, "Id", "Name");

            return View(new SeatingViewModel());
        }

        [HttpPost]
        public IActionResult Generate(SeatingViewModel model)
        {
            ViewBag.Batches = new SelectList(_context.Batches, "Id", "Name", model.BatchId);
            ViewBag.Sections = new SelectList(_context.Sections, "Id", "Name", model.SectionId);
            ViewBag.Courses = new SelectList(_context.Courses, "Id", "Name", model.CourseId);
            ViewBag.Rooms = new SelectList(_context.Rooms, "Id", "Name", model.RoomId);

            if (!_context.Batches.Any(b => b.Id == model.BatchId))
            {
                ModelState.AddModelError("BatchId", "Selected batch does not exist.");
                return View(model);
            }

            if (!_context.Sections.Any(s => s.Id == model.SectionId))
            {
                ModelState.AddModelError("SectionId", "Selected section does not exist.");
                return View(model);
            }

            // Get students in selected section
            var students = _context.Students
                .Where(s => s.SectionId == model.SectionId)
                .OrderBy(s => s.RollNumber)
                .ToList();

            foreach (var student in students)
            {
                var plan = new SeatingPlan
                {
                    StudentId = student.Id,
                    CourseId = model.CourseId,
                    RoomId = model.RoomId,
                    BatchId = model.BatchId,
                    SectionId = model.SectionId,
                    ExamDate = model.ExamDate,
                    StartTime = model.StartTime,
                    Duration = model.Duration
                };
                _context.SeatingPlans.Add(plan);
            }

            _context.SaveChanges();

            model.Students = students;
            TempData["Message"] = "Seating plan generated and saved.";
            return View(model);
        }

        [HttpPost]
        public IActionResult ExportPdf(SeatingViewModel model)
        {
            var students = _context.Students
                .Where(s => s.SectionId == model.SectionId)
                .OrderBy(s => s.RollNumber)
                .ToList();

            var batchName = _context.Batches.FirstOrDefault(b => b.Id == model.BatchId)?.Name ?? "N/A";
            var sectionName = _context.Sections.FirstOrDefault(s => s.Id == model.SectionId)?.Name ?? "N/A";
            var roomName = _context.Rooms.FirstOrDefault(r => r.Id == model.RoomId)?.Name ?? "N/A";

            var html = $@"
                <h2 style='text-align:center;'>Seating Plan</h2>
                <p><strong>Batch:</strong> {batchName}</p>
                <p><strong>Section:</strong> {sectionName}</p>
                <p><strong>Room:</strong> {roomName}</p>
                <p><strong>Exam Date:</strong> {model.ExamDate:dd/MM/yyyy}</p>

                <table border='1' cellspacing='0' cellpadding='5' width='100%'>
                    <thead>
                        <tr>
                            <th>Seat No</th>
                            <th>Student Name</th>
                            <th>Roll Number</th>
                            <th>Signature</th>
                        </tr>
                    </thead>
                    <tbody>";

            int seatNo = 1;
            foreach (var s in students)
            {
                html += $"<tr><td>{seatNo++}</td><td>{s.Name}</td><td>{s.RollNumber}</td><td></td></tr>";
            }

            html += "</tbody></table>";

            HtmlToPdf converter = new HtmlToPdf();
            PdfDocument doc = converter.ConvertHtmlString(html);
            byte[] pdf = doc.Save();
            doc.Close();

            return File(pdf, "application/pdf", "SeatingPlan.pdf");
        }
    }
}
