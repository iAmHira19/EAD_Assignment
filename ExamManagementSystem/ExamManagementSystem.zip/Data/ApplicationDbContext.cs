﻿//namespace ExamManagementSystem.Data
//{
//    public class ApplicationDbContext
//    {
//    }
//}



using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ExamManagementSystem.Models;

namespace ExamManagementSystem.Data
{
    public class ApplicationDbContext : IdentityDbContext<IdentityUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Batch> Batches { get; set; }
        public DbSet<Section> Sections { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Room> Rooms { get; set; }
        public DbSet<SeatingPlan> SeatingPlans { get; set; }
        public DbSet<Course> Courses { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<SeatingPlan>()
                .HasOne(sp => sp.Batch)
                .WithMany()
                .HasForeignKey(sp => sp.BatchId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<SeatingPlan>()
                .HasOne(sp => sp.Section)
                .WithMany()
                .HasForeignKey(sp => sp.SectionId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<SeatingPlan>()
                .HasOne(sp => sp.Room)
                .WithMany()
                .HasForeignKey(sp => sp.RoomId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<SeatingPlan>()
    .HasOne(sp => sp.Student)
    .WithOne()
    .HasForeignKey<SeatingPlan>(sp => sp.StudentId)
    .OnDelete(DeleteBehavior.Restrict);


        }
    }
}
